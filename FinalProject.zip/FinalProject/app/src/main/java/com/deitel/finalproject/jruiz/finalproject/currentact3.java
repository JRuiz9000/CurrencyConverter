//MainActivity.java
//Calculates a bill total based on a tip percentage

package com.deitel.finalproject.jruiz.finalproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import java.text.NumberFormat;

//import android.view.View;
//import android.widget.Toast;

// MainActivity class for the Tip Calculator app
public class currentact3 extends AppCompatActivity {

    // currency and percent formatter objects
    private static final NumberFormat currencyFormat =
            NumberFormat.getCurrencyInstance();
    private static final NumberFormat percentFormat =
            NumberFormat.getPercentInstance();

    private double percentSplit = .50;//PERCENT OF BILL SPLIT BETWEEN CURRENCIES
    private double billAmount = 0.0; // bill amount entered by the user
    private double percent = 0.15; // initial tip percentage
    private TextView amountTextView; // shows formatted bill amount
    private TextView percentTextView; // shows tip percentage
    private TextView convCurTextView; // shows percentage of currency label to be converted
    private TextView tipTextView; // shows calculated tip amount
    private TextView totalTextView; // shows calculated total bill amount
    private TextView conTextView; //shows percentage of currency to be converted

    SeekBar percentSeekBar; //Global Variable
    SeekBar percentSeekBar1; //Global Variable


    // called when the activity is first created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //call superclass's version
        setContentView(R.layout.activity_currentact3); //inflate the GUI

        // get references to programmatically manipulated TextViews
        amountTextView = (TextView) findViewById(R.id.amountTextView);
        percentTextView = (TextView) findViewById(R.id.percentTextView);
        tipTextView = (TextView) findViewById(R.id.tipTextView);
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        convCurTextView = (TextView) findViewById(R.id.convCurTextView);
        conTextView = (TextView) findViewById(R.id.conTextView);
        //tipTextView.setText(currencyFormat.format(0)); //set text to 0
        //totalTextView.setText(currencyFormat.format(0)); //set text to 0
        //conTextView.setText(currencyFormat.format(0)); //set text to 0

        // set amountEditText's TextWatcher
        EditText amountEditText =
                (EditText) findViewById(R.id.amountEditText);
        amountEditText.addTextChangedListener(amountEditTextWatcher);

        // set percentSeekBar's OnSeekBarChangeListener
        percentSeekBar =
                (SeekBar) findViewById(R.id.percentSeekBar);
        percentSeekBar.setOnSeekBarChangeListener(seekBarListener);

        percentSeekBar1 =
                (SeekBar) findViewById(R.id.percentSeekBar1);
        percentSeekBar1.setOnSeekBarChangeListener(seekBarListener);

        //Intent intent = new Intent(this, currentact1.class);
        //intent.putExtra("Name of Message", messagetext);
        //startActivity(intent);
    }

    // calculate and display tip and total amounts
    private void calculate() {
        //format percent and display in percentTextView
        percentTextView.setText("Tip% " + percentFormat.format(percent));
        convCurTextView.setText("Con. Currency " + percentFormat.format(percentSplit));

        // calculate the tip and total
        double tip = billAmount * percent;
        double total = billAmount + tip;

        //COL PESO AMOUNT
        double ColPesoAmount = total * 2769.10 * percentSplit;

        //display tip and total formatted as currency
        tipTextView.setText(currencyFormat.format(tip));
        totalTextView.setText(currencyFormat.format(total));
        conTextView.setText("COL" + currencyFormat.format(ColPesoAmount)); //Uses $ sign but country code included for clarity
    }

    // listener object for the Seekbar's progress changed events
    private final OnSeekBarChangeListener seekBarListener =
            new OnSeekBarChangeListener() {
                // update percent, then call calculate
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)  {
                    if (seekBar.getId() == R.id.percentSeekBar) {
                        /* Do something that you want when the first SeekBar is change).*/
                        Log.d("Juan Ruiz", "Progress=" + progress);
                        percent = progress / 100.0; //set percent based on progress

                    }
                    else if (seekBar.getId() == R.id.percentSeekBar1) {
                        // Do something that you want when the second SeekBar is change). For now, to debug, add        Log.d(“YourName”, 2nd SeekBar progress=”+progress);
                        Log.d("Juan Ruiz", "Progress=" + progress);
                        percentSplit = progress/100.0;

                    }
                    calculate(); // calculate and display tip and total
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) { }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) { }
            };

    // listener object for the EditText's text-changed events
    private final TextWatcher amountEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {


            try { //get bill amount and display currency formatted value
                billAmount = Double.parseDouble(s.toString())/100;
                amountTextView.setText(currencyFormat.format(billAmount));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                amountTextView.setText("");
                billAmount = 0.0;
            }

            calculate(); //update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

    };
}
/*
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import java.lang.String;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Intent intent = new Intent(this, currentact1.class);
    //intent.putExtra("Name of Message", messagetext);
    //startActivity(intent);

    //hostActivity.yourVariable;
} */
