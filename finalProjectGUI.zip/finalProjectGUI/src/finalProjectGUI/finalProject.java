package finalProjectGUI;

import java.awt.EventQueue;
import javax.swing.Timer;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.awt.Font;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
//import java.util.Scanner;
//import finalProjectGUI.fileIO;
//import finalProjectGUI.socketUtils;

public class finalProject extends JFrame {

	private static final long serialVersionUID = 1L;
	private int initializer; //Integer value for timer
	private final static int timeInterval = 100; //Sets a time interval to work with
	private JPanel contentPanel; // Sets the panel that will contain the main features of the program 
	private JLabel twitterLabel, logoLabel, progressLabel; //Sets a Label to prompt the user to "Enter Twitter Handle" in the TextField, sets Label to include Logo, set Label for the use of the ProgressBar
	private JTextField twitterHandle; //Sets a TextField for the user to input a Twitter Handle
	private JTextArea twitterOutput; //Displays the TextArea where the results will be shown
	private JButton twitterInput, logInput; //Sets a Button that, when clicked, will display the results in the TextArea and a Button to record input to a Log File
	private JProgressBar twitterProgress; //Sets a Percent Bar to Display how much of a particular sentiment is read 
	private Timer timer; //Sets a timer to be set in the progress bar 
	
public finalProject() {
		// TODO Auto-generated constructor stub
	
	   // Frame title
	   setTitle("--- Twitter Sentiment Analyzer ---");
				
				
	   setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
	   // size of the frame
	   setSize(975,800);
				
	   //Creates the main panel through which to run the experiment
	   contentPanel = new JPanel();
	   contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
	   contentPanel.setBorder(new TitledBorder(new EtchedBorder(), "Twitter Output"));;
	   setContentPane(contentPanel);
	   contentPanel.setLayout(null);
	   //contentPanel.setVisible(true);
	   
	   getContentPane().setBackground(Color.GRAY);
				
	   // Creates the TextArea which will display all of the readings
	   //Outputs percent based on Class (Testing with "Happy" or "Sad" as preliminary steps to more advanced categories : "Sarcasm"
	   //Plan to Include Loop: If 0-40% , display "Hey, you're too serious, lighten up a bit", 50-70%: "You're a Pretty Punny Person"
	   //80-100% : "The sarcasm is strong in this one...."
	   twitterOutput = new JTextArea();
	   twitterOutput.setBounds(244, 444, 484, 150);
	   twitterOutput.setEditable(false);
       contentPanel.add(twitterOutput);
        
       //Creates Label that works with TextField to prompt the user to input the TwitterHandle
       twitterLabel = new JLabel("Enter Twitter Handle");
       twitterLabel.setFont(new Font("Helvetica", Font.ROMAN_BASELINE, 14));
       twitterLabel.setBounds(240, 250, 140, 83);
       contentPanel.add(twitterLabel);
        
       //Creates the label to contain the Twitter Logo Image and sets it in the panel
       logoLabel = new JLabel("");
       logoLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
       logoLabel.setIcon(new ImageIcon("Twitter_logo_bird_transparent_bestfit_black.jpg")); //Twitter_logo_bird_transparent_bestfit.jpg
       logoLabel.setBounds(0, -30, 300, 300);
       contentPanel.add(logoLabel);
       
       //Creates Label that works with Progress to identify the ProgressBar
       progressLabel = new JLabel("Sarcasm Meter");
       progressLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
       progressLabel.setBounds(240, 345, 100, 23);
       contentPanel.add(progressLabel);
        
       //Creates the TextField where the user inputs the Twitter Handle
	   twitterHandle = new JTextField();
	   twitterHandle.setEditable(true);
	   twitterHandle.setBounds(370, 275, 184, 34);
	   contentPanel.add(twitterHandle);
	   twitterHandle.setColumns(10);
	   
	   //Creates the PercentBar as a ProgressBar
	   twitterProgress = new JProgressBar(0, 100);
	   twitterProgress.setValue(0);
	   twitterProgress.setStringPainted(true);
	   twitterProgress.setBounds(370, 345, 184, 34);
	   contentPanel.add(twitterProgress);
	   			
	   //Submit Button, takes the Twitter Handle that is entered by the user and runs it through the system to bring out a sarcasm reading 
	   twitterInput = new JButton("Submit");
	   twitterInput.addActionListener(new ActionListener()
	   {
		 public void actionPerformed(ActionEvent e)
		 {
			 
			String twitterID = twitterHandle.getText();
			//double percentCalc = Double.parseDouble(twitterID);
			
			twitterInput.setEnabled(false);
			timer.start();
			
			twitterOutput.append("The Level Of Sarcasm Displayed Is:     \r\n"); //message displayed when the Twitter Handle is read and passed through the System
			
			//New Stuff
			/*fileIO fl = new fileIO();
			fl.wrTransactionData(twitterHandle.getText());
						
			Thread t = new Thread(new Runnable()
			{
				public void run()
				{
					socketUtils su = new socketUtils();
								
					if(su.socketConnect() == true)
					{
						su.sendMessage(twitterHandle.getText());
									
						String recvMsgStr = su.recvMessage();
						su.sendMessage("QUIT>");
									
						su.closeSocket();
									
						JOptionPane.showMessageDialog(null, "Message : " + recvMsgStr, "Client", JOptionPane.WARNING_MESSAGE);
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "ERROR: Connection To Socket Server Is Down!", "Client", JOptionPane.WARNING_MESSAGE);
					}
				}
			});
								
			t.start();
						
			try
		    {
			   Thread.sleep(500);
		    }
					    
			   catch (InterruptedException e1)
			   {
				   // TODO Auto-generated catch block
				   e1.printStackTrace();
					    	
			   }*/
					    
				   twitterHandle.setText("");
						
						
				   twitterOutput.repaint();  	
			}
		});
				
		 twitterInput.setBounds(560, 275, 90, 34);
		 contentPanel.add(twitterInput);
		 
		 //Sets Timer for use in ProgressBar
		  timer = new Timer(timeInterval, new ActionListener() {
			   
			   public void actionPerformed(ActionEvent e)
			   {
			       if(initializer == 100){
			    	   
			    	   timer.stop();
			    	   twitterInput.setEnabled(true);
			       }
			       else{
			    	
			    	   initializer++;
			    	   twitterProgress.setValue(initializer);
		           }
			       
			       if(initializer == 40){
			    	   
			    	   twitterOutput.append("Hey, you're too serious, lighten up a bit      \r\n");
			       }
			       else if(initializer == 70){
			    	   
			    	   twitterOutput.append("You're a Pretty Punny Person      \r\n");
			       }
			       else if(initializer == 99) {
			    	   
			    	   twitterOutput.append("The sarcasm is strong in this one....    \r\n");
			       }
			   }
		   });
		 
		 
		 //Sets new button to record results in a log 		
		 logInput = new JButton("Twitter Log");
		 logInput.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent e)
		 {
			final JTextArea logArea = new JTextArea(35, 150);
			logArea.setEditable(false);
			logArea.setBackground(new Color(176, 224, 230));
			logArea.setFont(new Font("Courier New", Font.BOLD, 14));
			logArea.setForeground(Color.black);
						
			JFrame frameRecordLog = new JFrame("Twitter Log ");
		    try
		    {
			   File fileRecord = new File("TwitterLog.txt");
			   if (fileRecord.exists())
			   {
				  FileReader reader = new FileReader("TwitterLog.txt");
				  BufferedReader newReader = new BufferedReader(reader);
				  logArea.read(newReader, null);
				  newReader.close();
				                   
				  logArea.requestFocus();
				  frameRecordLog.getContentPane().add(new JScrollPane(logArea), BorderLayout.NORTH);
				             
				  frameRecordLog.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				  frameRecordLog.pack();
						           
				  frameRecordLog.setLocationRelativeTo(null);
				  frameRecordLog.setVisible(true);
			   }				
		    }
				  catch(Exception e2)
				  { 
				        
				  }
			   }
			});
				
			logInput.setBounds(660, 275, 100, 34);
			contentPanel.add(logInput);
				
				
	        // position frame in the middle of the screen
	        this.setLocationRelativeTo(null);
	}

    public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					finalProject frame = new finalProject();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

}